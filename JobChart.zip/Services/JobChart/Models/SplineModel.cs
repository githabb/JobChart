﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobChart.Models
{
    public class SplineModel
    {
        public int Id { get; set; }
        public string Letter { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
