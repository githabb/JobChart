﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobChart.Models
{
    public class PieModel
    {
        public int Id { get; set; }
        public string Month { get; set; }
        public int Percent { get; set; }
    }
}
