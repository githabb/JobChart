﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobChart.Models
{
    public class PolarModel
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public int Car { get; set; }
        public int Bus { get; set; }
        public int Tractors { get; set; }
    }
}
