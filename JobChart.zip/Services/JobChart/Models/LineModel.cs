﻿namespace JobChart.Models
{
    public class LineModel
    {
        public int Id { get; set; }
        public decimal Value { get; set; }
    }
}
