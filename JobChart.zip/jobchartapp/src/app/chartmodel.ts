export class ChartModel{
    id: number;
    name: string;
}