import { Component, OnInit} from '@angular/core';
import { HttpService} from './http.service';
import {ChartModel} from './chartmodel';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [HttpService]
})
export class AppComponent implements OnInit {
  title = 'Job Chart App';

  charts: ChartModel[] = [];
     
  constructor(private httpService: HttpService){}
      
  ngOnInit(){          
    this.httpService.getChartList().subscribe(data => this.charts = <ChartModel[]>data);
  }

  chart = new Chart({
    chart: {
      type: 'line'
    },
    title: {
      text: 'Line chart'
    },
    credits: {
      enabled: false
    },
    series: [{
      name: 'Line',
      data: [1, 2, 3]
    }]
  });
}
